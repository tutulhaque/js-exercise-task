const pancakeType = document.querySelector("#type");
const toppings = document.querySelectorAll(".topping");
const extras = document.querySelectorAll(".extra");
const deliveries = document.querySelectorAll(".delivery");
const totalPriceDisplay = document.querySelector("#totalPriceDisplay");
const totalPriceBanner = document.querySelector("#totalPrice");
const panCakeForm = document.querySelector("#pancakeForm");

const calculateTotal = () => {
  let totalPrice = parseFloat(pancakeType.value);
  console.log("event was triggered");

  toppings.forEach((topping) => {
    if (topping.checked) {
      totalPrice += parseFloat(topping.value);
    }
  });

  extras.forEach((extra) => {
    if (extra.checked) {
      totalPrice += parseFloat(extra.value);
    }
  });

  // Correcting the delivery selection
  const selectedDelivery = document.querySelector(".delivery:checked");
  if (selectedDelivery) {
    totalPrice += parseFloat(selectedDelivery.value);
  }

  totalPriceDisplay.textContent = `${totalPrice}€`;
  totalPriceBanner.textContent = `${totalPrice}€`;
};

pancakeType.addEventListener("change", calculateTotal);
toppings.forEach((topping) =>
  topping.addEventListener("change", calculateTotal)
);
extras.forEach((extra) => extra.addEventListener("change", calculateTotal));
deliveries.forEach((delivery) =>
  delivery.addEventListener("change", calculateTotal)
);

const changeHandler = (event) => {
  console.log(event.target);
  console.log(event.target.value);
};
panCakeForm.addEventListener("change", changeHandler);
