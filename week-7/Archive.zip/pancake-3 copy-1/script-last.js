const pancakeForm = document.getElementById("pancakeForm");
const pancakeType = document.getElementById("type");
const customerName = document.getElementById("customerName");

const changeHandler = (event) => {
  console.log(event.target);
  console.log(event.target.value);
};

pancakeForm.addEventListener("change", changeHandler);
