// const pancakeForm = document.querySelector("#pancakeForm");
// const customerName = document.getElementById("customerName");
// const pancakeType = document.getElementById("type");
// const toppings = document.querySelectorAll(".topping");
// const extras = document.querySelectorAll(".extra");
// const deliveries = document.querySelectorAll(".delivery");
// const totalPriceDisplay = document.getElementById("totalPriceDisplay");
// const totalPriceTop = document.getElementById("totalPrice");
// const summaryText = document.getElementById("summaryText");

// const calculateTotal = () => {
//   let totalPrice = parseFloat(pancakeType.value);
//   // forEach for extras
//   extras.forEach((extra) => {
//     if (extra.checked) {
//       totalPrice += parseFloat(extra.value);
//       let extraDisplay = extra.value;
//       console.log("extras");
//       console.log(extraDisplay);
//     }
//   });
//   // forEach for Topping
//   toppings.forEach((topping) => {
//     if (topping.checked) {
//       totalPrice += parseFloat(topping.value);
//     }
//   });
//   // code for Delivery
//   const selectedDelivery = document.querySelector(".delivery:checked");
//   totalPrice += parseFloat(selectedDelivery.value);
//   // Display price
//   totalPriceDisplay.innerText = totalPrice;
//   totalPriceTop.innerText = totalPrice;
//   // show details
//   // summaryText.innerText = ;
// };
// pancakeForm.addEventListener("change", calculateTotal);
