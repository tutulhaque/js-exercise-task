// const changeHandler = (event) => {
//   console.log("event", event);
//   const basePrice = parseFloat(
//     document.getElementById("type").selectedOptions[0].dataset.price
//   );
//   console.log(basePrice);

//   const toppingsTotal = [
//     ...document.querySelectorAll(".topping:checked"),
//   ].reduce((sum, topping) => sum + parseFloat(topping.dataset.price), 0);
//   console.log("Toppings Total: ", toppingsTotal);

//   const extraTotal = [...document.querySelectorAll(".extra:checked")].reduce(
//     (sum, extra) => sum + parseFloat(extra.dataset.price),
//     0
//   );
//   console.log("Extra Total: ", extraTotal);

//   totalPriceDisplay.textContent = `${basePrice}€`;
//   totalPriceBanner.textContent = `${basePrice}€`;
// };
// panCakeForm.addEventListener("change", changeHandler);

// const changeHandler = (event) => {
//   const basePrice = pancakeType.selectedOptions[0].dataset.price;
//   console.log(basePrice);
// };
// panCakeForm.addEventListener("change", changeHandler);
