// const cakeType = document.getElementById("type");
// const selectToppings = document.querySelectorAll(".topping");
// const selectExtras = document.querySelectorAll(".extra");
// let count = 0;
// let extra = 0;

// const typeValue = addEventListener("change", function () {
//   const selectedValue = cakeType.value;
//   //   console.log("selected Value", selectedValue);
// });

// selectToppings.forEach((topping) => {
//   topping.addEventListener("change", function () {
//     if (topping.checked) {
//       count++;
//     } else {
//       count--;
//     }
//     // console.log("Selected Toppings Count:", count);
//   });
// });

// selectExtras.forEach((extra) => {
//   extra.addEventListener("change", function () {
//     let total = 0;
//     selectExtras.forEach((extra) => {
//       if (extra.checked) {
//         total += parseFloat(extra.value);
//       }
//       //   console.log("Total extra", total);
//     });
//   });
// });
// console.log("count value is:", count, "extra value is", extra);
